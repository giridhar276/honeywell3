
import psutil

# 1. Get CPU times
cpu_times = psutil.cpu_times()
print("CPU Times:", cpu_times)

# 2. Get CPU usage percentage
cpu_usage = psutil.cpu_percent(interval=1)
print(f"CPU Usage: {cpu_usage}%")

# 3. Get virtual memory statistics
virtual_memory = psutil.virtual_memory()
print("Virtual Memory:", virtual_memory)

# 4. Get swap memory statistics
swap_memory = psutil.swap_memory()
print("Swap Memory:", swap_memory)

# 5. Get disk partitions
disk_partitions = psutil.disk_partitions()
print("Disk Partitions:", disk_partitions)

# 6. Get disk usage
disk_usage = psutil.disk_usage('/')
print(f"Disk Usage: {disk_usage.percent}%")

# 7. Get disk I/O statistics
disk_io = psutil.disk_io_counters()
print("Disk I/O:", disk_io)

# 8. Get network I/O statistics
network_io = psutil.net_io_counters()
print("Network I/O:", network_io)

# 9. Get network connections
network_connections = psutil.net_connections()
print("Network Connections:", network_connections)

# 10. Get process information
for proc in psutil.process_iter(['pid', 'name']):
    print(proc.info)
