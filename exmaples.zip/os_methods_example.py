
import os

# 1. Get the current working directory
print("Current Working Directory:", os.getcwd())

# 2. Change the current working directory
os.chdir('/tmp')
print("Changed Working Directory:", os.getcwd())

# 3. List files and directories in a directory
print("Files in /tmp:", os.listdir('.'))

# 4. Create a new directory
os.makedirs('example_dir', exist_ok=True)
print("Created directory 'example_dir'")

# 5. Remove a directory
os.rmdir('example_dir')
print("Removed directory 'example_dir'")

# 6. Create a new file
with open('example_file.txt', 'w') as f:
    f.write('Hello, world!')

# 7. Rename a file
os.rename('example_file.txt', 'renamed_file.txt')
print("Renamed file to 'renamed_file.txt'")

# 8. Remove a file
os.remove('renamed_file.txt')
print("Removed file 'renamed_file.txt'")

# 9. Check if a path exists
print("Does '/tmp' exist?", os.path.exists('/tmp'))

# 10. Get the size of a file
with open('example_file.txt', 'w') as f:
    f.write('Hello, world!')
print("Size of 'example_file.txt':", os.path.getsize('example_file.txt'))
os.remove('example_file.txt')
