
import shutil
import os

# Ensure the example files exist
with open('source_file.txt', 'w') as f:
    f.write('This is a source file.')

os.makedirs('example_dir', exist_ok=True)
with open('example_dir/example_file.txt', 'w') as f:
    f.write('This is a file in a directory.')

# 1. Copy a file
shutil.copy('source_file.txt', 'copied_file.txt')
print("Copied 'source_file.txt' to 'copied_file.txt'")

# 2. Copy a directory
shutil.copytree('example_dir', 'copied_dir')
print("Copied directory 'example_dir' to 'copied_dir'")

# 3. Move a file
shutil.move('copied_file.txt', 'moved_file.txt')
print("Moved 'copied_file.txt' to 'moved_file.txt'")

# 4. Move a directory
shutil.move('copied_dir', 'moved_dir')
print("Moved directory 'copied_dir' to 'moved_dir'")

# 5. Remove a file
os.remove('moved_file.txt')
print("Removed 'moved_file.txt'")

# 6. Remove a directory
shutil.rmtree('moved_dir')
print("Removed directory 'moved_dir'")

# 7. Copy file permissions
shutil.copymode('source_file.txt', 'source_file_copy.txt')
print("Copied permissions from 'source_file.txt' to 'source_file_copy.txt'")

# 8. Copy file metadata
shutil.copystat('source_file.txt', 'source_file_copy.txt')
print("Copied metadata from 'source_file.txt' to 'source_file_copy.txt'")

# 9. Copy file content and metadata
shutil.copy2('source_file.txt', 'source_file_copy2.txt')
print("Copied file content and metadata to 'source_file_copy2.txt'")

# 10. Disk usage statistics
disk_usage = shutil.disk_usage('/')
print(f"Disk usage: Total: {disk_usage.total}, Used: {disk_usage.used}, Free: {disk_usage.free}")
