
# Best Practices for Writing Python Applications

# 1. Code Organization and Structure

# Example of a well-organized project structure
# my_project/
# │
# ├── src/
# │   ├── __init__.py
# │   ├── main.py
# │   ├── module1.py
# │   └── module2.py
# │
# ├── tests/
# │   ├── __init__.py
# │   ├── test_module1.py
# │   └── test_module2.py
# │
# ├── docs/
# │   └── index.md
# │
# ├── requirements.txt
# └── README.md

# 2. Modular Design

# src/module1.py
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

# src/main.py
import module1

result_add = module1.add(5, 3)
result_subtract = module1.subtract(5, 3)

print(f"Addition Result: {result_add}")
print(f"Subtraction Result: {result_subtract}")

# 3. Coding Standards

# Follow PEP 8 guidelines
# Good:
def calculate_area(radius):
    return 3.14 * radius * radius

# Bad:
def calculateArea(radius):
    return 3.14 * radius * radius

# 4. Readability and Documentation

# Example of using docstrings and comments
def multiply(a, b):
    """
    Multiply two numbers and return the result.
    
    Parameters:
    a (int): The first number
    b (int): The second number
    
    Returns:
    int: The multiplication result
    """
    return a * b

# Using the multiply function
result_multiply = multiply(5, 3)
print(f"Multiplication Result: {result_multiply}")

# 5. Error Handling and Logging

import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def divide(a, b):
    try:
        result = a / b
        return result
    except ZeroDivisionError as e:
        logging.error("Attempted to divide by zero")
        return None

# Using the divide function
result_divide = divide(10, 0)
print(f"Division Result: {result_divide}")

# 6. Dependency Management

# Example of a requirements.txt file
requirements = """
flask==2.0.1
requests==2.25.1
numpy==1.21.0
"

with open('requirements.txt', 'w') as f:
    f.write(requirements)

# Note: In a real script, you would run the following command in a shell:
# !pip install -r requirements.txt

# 7. Performance Optimization

# Example of using list comprehension for better performance
numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(squares)

# Compare with a regular loop
squares_loop = []
for x in numbers:
    squares_loop.append(x**2)
print(squares_loop)

# 8. Documentation

# Example using Sphinx for documentation
# Create a Sphinx documentation
# !sphinx-quickstart

# Edit the source files and build the docs
# !make html

# 9. Version Control

# Example using Git
# Initialize a Git repository
# !git init

# Add files to the repository
# !git add .

# Commit changes
# !git commit -m "Initial commit"

# Create a new branch
# !git checkout -b feature-branch

# Merge changes
# !git merge feature-branch
